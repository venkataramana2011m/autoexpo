package com.adobe.aem.guides.autoexpo.core.services;

import org.apache.sling.api.resource.ResourceResolver;

public interface ResourceResolverService {
	ResourceResolver getResourceResolver();
}
