package com.adobe.aem.guides.autoexpo.core.services;

public interface WriteTODOService {

	void writeData(String todoData);
}
